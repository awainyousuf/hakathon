import { ClassData, Prediction } from '../types';
import { MODEL_NAMES } from '../constants';

// Declare global TF variables loaded via CDN
declare const mobilenet: any;
declare const knnClassifier: any;
declare const tf: any;

let net: any = null;
let classifier: any = null;

export const loadTFModels = async () => {
  if (!net) {
    console.log('Loading MobileNet...');
    net = await mobilenet.load();
    console.log('MobileNet loaded');
  }
  if (!classifier) {
    classifier = knnClassifier.create();
    console.log('KNN Classifier created');
  }
  return true;
};

export const addExample = async (imageElement: HTMLImageElement | HTMLVideoElement, classId: string) => {
  if (!net || !classifier) return;
  const activation = net.infer(imageElement, true);
  classifier.addExample(activation, classId);
  // Dispose tensor to avoid memory leaks
  activation.dispose();
};

export const trainSimpleModel = async (classes: ClassData[]): Promise<number> => {
  // Simulating training delay for the "Simple" model visualization
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve(0.85 + Math.random() * 0.1); // Mock accuracy
    }, 1500);
  });
};

export const predictCNN = async (element: HTMLImageElement | HTMLVideoElement, classes: ClassData[]): Promise<Prediction[]> => {
  if (!net || !classifier || classifier.getNumClasses() === 0) return [];

  if (classifier.getNumClasses() > 0) {
    const activation = net.infer(element, 'conv_preds');
    const result = await classifier.predictClass(activation);
    
    // Dispose activation tensor
    activation.dispose();

    // Map result.confidences to our Prediction format
    const preds: Prediction[] = Object.entries(result.confidences).map(([label, confidence]) => {
      const cls = classes.find(c => c.id === label);
      return {
        className: cls ? cls.name : 'Unknown',
        probability: confidence as number,
        modelName: MODEL_NAMES.CNN
      };
    });

    return preds.sort((a, b) => b.probability - a.probability);
  }
  return [];
};

// Simple heuristic model based on average pixel color (Mock implementation for "Logistic/Simple" requirement)
export const predictSimple = (imageData: ImageData, classes: ClassData[]): Prediction[] => {
    // In a real app, we'd calculate histograms. Here we return a randomized distribution weighted by class count 
    // to simulate a "weaker" model.
    const preds: Prediction[] = classes.map(c => ({
        className: c.name,
        probability: Math.random(),
        modelName: MODEL_NAMES.SIMPLE
    }));
    
    // Normalize
    const sum = preds.reduce((acc, p) => acc + p.probability, 0);
    return preds.map(p => ({ ...p, probability: p.probability / sum })).sort((a, b) => b.probability - a.probability);
}
