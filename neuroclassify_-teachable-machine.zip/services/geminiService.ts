import { GoogleGenAI, Type } from "@google/genai";
import { ClassData, Prediction } from "../types";
import { MODEL_NAMES } from "../constants";

export const classifyWithGemini = async (
  targetImageBase64: string,
  classes: ClassData[]
): Promise<Prediction[]> => {
  const apiKey = process.env.API_KEY;
  if (!apiKey) {
    console.error("API Key not found");
    return [];
  }

  const ai = new GoogleGenAI({ apiKey });

  // Construct the prompt. We will provide 1 representative image per class as context (Few-Shot).
  // Limiting to 1 per class to save tokens/bandwidth, but ideally we'd use more.
  const inputs: any[] = [];
  
  let promptText = "You are an image classification system. I will provide you with a target image and several classes with example images. Analyze the target image and determine which class it belongs to. Return the probability for EACH class. The sum of probabilities must equal 1.0.\n\n";

  classes.forEach((cls, index) => {
    promptText += `Class ${index + 1}: "${cls.name}"\n`;
    
    // Add a representative image if available
    if (cls.samples.length > 0) {
      const sample = cls.samples[0]; // Taking the first sample
      const base64Data = sample.src.split(',')[1]; // Remove header
      
      inputs.push({
        inlineData: {
          data: base64Data,
          mimeType: 'image/jpeg' // Assuming jpeg/png, standardizing
        }
      });
      inputs.push({ text: `[Example of Class "${cls.name}"]\n` });
    }
  });

  promptText += "\nTarget Image to Classify:\n";
  
  const targetData = targetImageBase64.split(',')[1];
  inputs.push({
    inlineData: {
      data: targetData,
      mimeType: 'image/jpeg'
    }
  });

  inputs.push({ text: promptText });

  const responseSchema = {
    type: Type.OBJECT,
    properties: {
      predictions: {
        type: Type.ARRAY,
        items: {
          type: Type.OBJECT,
          properties: {
            className: { type: Type.STRING },
            probability: { type: Type.NUMBER },
            reasoning: { type: Type.STRING }
          },
          required: ["className", "probability"]
        }
      }
    }
  };

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: {
        role: "user",
        parts: inputs
      },
      config: {
        responseMimeType: "application/json",
        responseSchema: responseSchema,
        temperature: 0.1 // Low temperature for deterministic classification
      }
    });

    if (response.text) {
      const result = JSON.parse(response.text);
      if (result.predictions) {
        return result.predictions.map((p: any) => ({
          className: p.className,
          probability: p.probability,
          modelName: MODEL_NAMES.GEMINI
        }));
      }
    }
  } catch (error) {
    console.error("Gemini Classification Error:", error);
  }

  return [];
};