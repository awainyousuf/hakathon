import React, { useState, useEffect, useRef } from 'react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell } from 'recharts';
import { Sparkles, Zap, Eye, Upload, RefreshCw, Image as ImageIcon } from 'lucide-react';
import { ClassData, Prediction, TrainingState } from '../types';
import { MODEL_NAMES } from '../constants';
import * as tfService from '../services/tensorService';
import { classifyWithGemini } from '../services/geminiService';

interface InferenceProps {
  classes: ClassData[];
  trainingState: TrainingState;
  webcamRef: React.RefObject<HTMLVideoElement>;
}

const Inference: React.FC<InferenceProps> = ({ classes, trainingState, webcamRef }) => {
  const [isPredicting, setIsPredicting] = useState(false);
  const [predictions, setPredictions] = useState<Prediction[]>([]);
  const [geminiLoading, setGeminiLoading] = useState(false);
  const [uploadedImage, setUploadedImage] = useState<string | null>(null);
  
  const uploadedImageRef = useRef<HTMLImageElement>(null);
  
  // Real-time loop for TF.js (Webcam)
  useEffect(() => {
    let animationId: number;
    
    const predictLoop = async () => {
      // Only run loop if predicting AND webcam is active (no uploaded image)
      if (
        isPredicting && 
        !uploadedImage &&
        webcamRef.current && 
        trainingState.trainedModels.includes('CNN') &&
        classes.length > 0
      ) {
        try {
          // 1. Get CNN Predictions
          const cnnPreds = await tfService.predictCNN(webcamRef.current, classes);
          
          // 2. Get Simple Predictions
          const simplePreds = tfService.predictSimple({} as ImageData, classes);

          setPredictions(prev => {
             // Preserve Gemini predictions
             const geminiPreds = prev.filter(p => p.modelName === MODEL_NAMES.GEMINI);
             return [...cnnPreds, ...geminiPreds];
          });

        } catch (e) {
          console.error(e);
        }
        animationId = requestAnimationFrame(predictLoop);
      }
    };

    if (isPredicting && !uploadedImage) {
      predictLoop();
    }

    return () => cancelAnimationFrame(animationId);
  }, [isPredicting, classes, trainingState, uploadedImage]);


  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      const reader = new FileReader();
      reader.onload = (event) => {
        if (event.target?.result) {
          setUploadedImage(event.target.result as string);
          setIsPredicting(false); // Stop live loop
          // Predictions will be triggered by onLoad of the image
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const clearUpload = () => {
    setUploadedImage(null);
    setPredictions([]);
  };

  const handleImageLoad = async () => {
    if (
      uploadedImageRef.current && 
      trainingState.trainedModels.includes('CNN') &&
      classes.length > 0
    ) {
      try {
        const cnnPreds = await tfService.predictCNN(uploadedImageRef.current, classes);
        setPredictions(prev => {
           // Clear old Gemini/CNN preds for a fresh image, or keep Gemini?
           // Usually new image = new predictions.
           return [...cnnPreds];
        });
      } catch (e) {
        console.error(e);
      }
    }
  };

  const handleGeminiPredict = async () => {
    if (!webcamRef.current && !uploadedImage) return;
    setGeminiLoading(true);

    try {
      let base64 = "";

      if (uploadedImage) {
        base64 = uploadedImage;
      } else if (webcamRef.current) {
        // Capture current frame from webcam
        const canvas = document.createElement('canvas');
        canvas.width = webcamRef.current.videoWidth;
        canvas.height = webcamRef.current.videoHeight;
        const ctx = canvas.getContext('2d');
        ctx?.drawImage(webcamRef.current, 0, 0);
        base64 = canvas.toDataURL('image/jpeg');
      }

      const results = await classifyWithGemini(base64, classes);
      
      setPredictions(prev => {
        // Remove old Gemini predictions
        const others = prev.filter(p => p.modelName !== MODEL_NAMES.GEMINI);
        return [...others, ...results];
      });
      
    } catch (e) {
      console.error(e);
    } finally {
      setGeminiLoading(false);
    }
  };

  // Preparing data for charts
  const cnnData = predictions.filter(p => p.modelName === MODEL_NAMES.CNN);
  const geminiData = predictions.filter(p => p.modelName === MODEL_NAMES.GEMINI);
  const getClassColor = (name: string) => classes.find(c => c.name === name)?.color || '#ccc';

  return (
    <div className="bg-slate-800 rounded-xl p-6 border border-slate-700 h-full flex flex-col">
       <div className="flex justify-between items-center mb-4">
          <h2 className="text-2xl font-bold flex items-center gap-2">
            <Eye className="text-blue-400" />
            Inference
          </h2>
          
          <div className="flex gap-2">
             {uploadedImage ? (
                <button
                  onClick={clearUpload}
                  className="px-4 py-1.5 rounded-lg text-sm font-medium bg-slate-700 text-white hover:bg-slate-600 transition-colors flex items-center gap-2"
                >
                  <RefreshCw size={14} />
                  Reset to Webcam
                </button>
             ) : (
               <>
                 <label className="cursor-pointer px-4 py-1.5 rounded-lg text-sm font-medium bg-slate-700 text-slate-300 hover:bg-slate-600 transition-colors flex items-center gap-2 border border-slate-600">
                    <Upload size={14} />
                    <span>Upload Image</span>
                    <input type="file" accept="image/*" className="hidden" onChange={handleFileUpload} />
                 </label>
                 <button
                   onClick={() => setIsPredicting(!isPredicting)}
                   disabled={!trainingState.trainedModels.includes('CNN')}
                   className={`px-4 py-1.5 rounded-full text-sm font-medium transition-colors flex items-center gap-2 ${
                     isPredicting 
                       ? 'bg-red-500/20 text-red-400 border border-red-500/50' 
                       : 'bg-slate-700 text-slate-300 hover:bg-slate-600'
                   }`}
                 >
                   <Zap size={14} />
                   {isPredicting ? 'Stop Live' : 'Start Live'}
                 </button>
               </>
             )}
          </div>
       </div>

       <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 flex-1">
          
          {/* Left: Input Source (Webcam or Image) */}
          <div className="flex flex-col gap-4">
            <div className="relative rounded-xl overflow-hidden bg-black border-2 border-slate-700 aspect-video group flex items-center justify-center">
                {uploadedImage ? (
                  <img 
                    ref={uploadedImageRef}
                    src={uploadedImage}
                    alt="Uploaded for inference"
                    className="max-w-full max-h-full object-contain"
                    onLoad={handleImageLoad}
                  />
                ) : (
                  <video 
                    ref={webcamRef} 
                    autoPlay 
                    playsInline 
                    muted 
                    className="w-full h-full object-cover"
                  />
                )}
                
                <div className="absolute bottom-4 right-4">
                  <button 
                    onClick={handleGeminiPredict}
                    disabled={geminiLoading || classes.length === 0}
                    className="bg-gradient-to-r from-indigo-500 to-purple-600 text-white px-4 py-2 rounded-lg shadow-lg hover:scale-105 transition-transform flex items-center gap-2 disabled:opacity-50 disabled:hover:scale-100"
                  >
                    <Sparkles size={16} />
                    {geminiLoading ? 'Reasoning...' : 'Ask Gemini'}
                  </button>
                </div>
                
                {uploadedImage && (
                   <div className="absolute top-4 left-4 bg-black/60 text-white px-2 py-1 rounded text-xs backdrop-blur-sm flex items-center gap-1">
                      <ImageIcon size={12} /> Static Image Mode
                   </div>
                )}
            </div>
            
            {!uploadedImage && !isPredicting && trainingState.trainedModels.includes('CNN') && (
               <p className="text-center text-xs text-slate-500">Click "Start Live" to run real-time CNN inference</p>
            )}
          </div>

          {/* Right: Results */}
          <div className="flex flex-col gap-4 overflow-y-auto max-h-[500px]">
             
             {/* CNN Results */}
             <div className="bg-slate-700/30 p-4 rounded-lg border border-slate-600">
                <div className="text-xs font-bold text-slate-400 uppercase mb-2 flex justify-between">
                  <span>MobileNet v2</span>
                  {uploadedImage ? (
                     <span className="text-blue-400">Static Prediction</span>
                  ) : (
                     <span className="text-green-400">~30ms latency</span>
                  )}
                </div>
                {cnnData.length > 0 ? (
                   <div className="h-40 w-full">
                     <ResponsiveContainer width="100%" height="100%">
                       <BarChart layout="vertical" data={cnnData}>
                         <XAxis type="number" domain={[0, 1]} hide />
                         <YAxis dataKey="className" type="category" width={80} tick={{fill: '#94a3b8', fontSize: 12}} />
                         <Tooltip 
                           contentStyle={{backgroundColor: '#1e293b', borderColor: '#334155', color: '#f1f5f9'}}
                           cursor={{fill: 'transparent'}}
                         />
                         <Bar dataKey="probability" radius={[0, 4, 4, 0]}>
                            {cnnData.map((entry, index) => (
                              <Cell key={`cell-${index}`} fill={getClassColor(entry.className)} />
                            ))}
                         </Bar>
                       </BarChart>
                     </ResponsiveContainer>
                   </div>
                ) : (
                  <div className="h-40 flex items-center justify-center text-slate-500 text-sm italic">
                    {uploadedImage ? 'Loading...' : 'Waiting for live stream...'}
                  </div>
                )}
             </div>

             {/* Gemini Results */}
             <div className="bg-slate-700/30 p-4 rounded-lg border border-slate-600 relative overflow-hidden">
                <div className="absolute top-0 left-0 w-1 h-full bg-gradient-to-b from-indigo-500 to-purple-500"></div>
                <div className="text-xs font-bold text-slate-400 uppercase mb-2 flex justify-between">
                  <span className="flex items-center gap-1"><Sparkles size={12} className="text-indigo-400"/> Gemini 2.5 (Reasoning)</span>
                  {geminiData.length > 0 && <span className="text-indigo-400">Analyzed</span>}
                </div>
                
                {geminiLoading ? (
                   <div className="h-40 flex items-center justify-center flex-col gap-2">
                      <div className="w-6 h-6 border-2 border-indigo-500 border-t-transparent rounded-full animate-spin"></div>
                      <span className="text-xs text-indigo-300">Analyzing visual features...</span>
                   </div>
                ) : geminiData.length > 0 ? (
                   <div className="space-y-2">
                      {geminiData.sort((a,b) => b.probability - a.probability).map((pred, idx) => (
                        <div key={idx} className="flex items-center gap-3">
                           <span className="text-sm text-slate-300 w-20 truncate text-right">{pred.className}</span>
                           <div className="flex-1 h-2 bg-slate-700 rounded-full overflow-hidden">
                              <div 
                                className="h-full rounded-full bg-gradient-to-r from-indigo-500 to-purple-500"
                                style={{ width: `${pred.probability * 100}%`}}
                              ></div>
                           </div>
                           <span className="text-xs font-mono text-indigo-300 w-10 text-right">{(pred.probability * 100).toFixed(0)}%</span>
                        </div>
                      ))}
                   </div>
                ) : (
                   <div className="h-40 flex items-center justify-center text-slate-500 text-sm italic">
                     Click "Ask Gemini" for advanced classification
                   </div>
                )}
             </div>

          </div>
       </div>
    </div>
  );
};

export default Inference;