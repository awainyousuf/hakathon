import React, { useRef, useState, useEffect } from 'react';
import { Camera, Upload, Trash2, Plus, Image as ImageIcon, X } from 'lucide-react';
import { ClassData, ImageSample } from '../types';
import { v4 as uuidv4 } from 'uuid';
import * as tfService from '../services/tensorService';

interface ClassManagerProps {
  classData: ClassData;
  onUpdate: (updatedClass: ClassData) => void;
  onDelete: (id: string) => void;
  webcamRef: React.RefObject<HTMLVideoElement>;
}

const ClassManager: React.FC<ClassManagerProps> = ({ classData, onUpdate, onDelete, webcamRef }) => {
  const [isCapturing, setIsCapturing] = useState(false);
  const captureInterval = useRef<number | null>(null);

  const handleCapture = async () => {
    if (!webcamRef.current) return;

    // Create canvas to capture frame
    const video = webcamRef.current;
    const canvas = document.createElement('canvas');
    canvas.width = 224; // MobileNet input size
    canvas.height = 224;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Draw video frame to canvas (center crop)
    const minSize = Math.min(video.videoWidth, video.videoHeight);
    const startX = (video.videoWidth - minSize) / 2;
    const startY = (video.videoHeight - minSize) / 2;
    
    ctx.drawImage(video, startX, startY, minSize, minSize, 0, 0, 224, 224);
    
    const dataUrl = canvas.toDataURL('image/jpeg');
    
    const newSample: ImageSample = {
      id: uuidv4(),
      src: dataUrl,
      timestamp: Date.now()
    };

    // Add to TF.js classifier immediately (Incremental Learning)
    // We create an image element from the data URL to pass to TF
    const img = new Image();
    img.src = dataUrl;
    img.onload = async () => {
       await tfService.addExample(img, classData.id);
    }

    onUpdate({
      ...classData,
      samples: [...classData.samples, newSample]
    });
  };

  const toggleAutoCapture = () => {
    if (isCapturing) {
      if (captureInterval.current) clearInterval(captureInterval.current);
      setIsCapturing(false);
    } else {
      setIsCapturing(true);
      captureInterval.current = window.setInterval(handleCapture, 100); // 10fps capture
    }
  };

  useEffect(() => {
    return () => {
      if (captureInterval.current) clearInterval(captureInterval.current);
    };
  }, []);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      const reader = new FileReader();
      reader.onload = (event) => {
        if (event.target?.result) {
          const dataUrl = event.target.result as string;
          const newSample: ImageSample = {
            id: uuidv4(),
            src: dataUrl,
            timestamp: Date.now()
          };
           // Add to TF
          const img = new Image();
          img.src = dataUrl;
          img.onload = async () => {
             await tfService.addExample(img, classData.id);
          }

          onUpdate({
            ...classData,
            samples: [...classData.samples, newSample]
          });
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const removeSample = (sampleId: string) => {
     // Note: Cannot remove from KNN classifier easily without retraining from scratch
     // For this demo, we just remove from UI list, but it stays in the model memory until page refresh
     onUpdate({
       ...classData,
       samples: classData.samples.filter(s => s.id !== sampleId)
     });
  };

  return (
    <div className="bg-slate-800 rounded-xl p-4 mb-4 border border-slate-700 shadow-lg">
      <div className="flex justify-between items-center mb-4">
        <div className="flex items-center gap-3">
          <div 
            className="w-4 h-12 rounded-full" 
            style={{ backgroundColor: classData.color }}
          />
          <input 
            type="text" 
            value={classData.name}
            onChange={(e) => onUpdate({ ...classData, name: e.target.value })}
            className="bg-transparent text-xl font-semibold text-white border-b border-slate-600 focus:border-blue-500 outline-none px-1"
          />
        </div>
        <button onClick={() => onDelete(classData.id)} className="text-slate-400 hover:text-red-400">
          <Trash2 size={20} />
        </button>
      </div>

      <div className="flex gap-2 mb-4">
        <button 
          onMouseDown={() => setIsCapturing(true)}
          onMouseUp={() => setIsCapturing(false)}
          onMouseLeave={() => setIsCapturing(false)}
          // Alternatively, use a Hold button approach or simple click
          onClick={handleCapture}
          className="flex-1 flex items-center justify-center gap-2 py-2 bg-blue-600 hover:bg-blue-500 rounded-lg active:scale-95 transition-all select-none"
        >
          <Camera size={18} />
          <span>Snap Webcam</span>
        </button>
        <label className="flex-1 flex items-center justify-center gap-2 py-2 bg-slate-700 hover:bg-slate-600 rounded-lg cursor-pointer transition-all">
          <Upload size={18} />
          <span>Upload</span>
          <input type="file" accept="image/*" className="hidden" onChange={handleFileUpload} />
        </label>
      </div>

      <div className="flex gap-2 overflow-x-auto pb-2 min-h-[80px]">
        {classData.samples.length === 0 && (
          <div className="w-full flex flex-col items-center justify-center text-slate-500 text-sm italic border-2 border-dashed border-slate-700 rounded-lg">
            <ImageIcon size={24} className="mb-1 opacity-50"/>
            No samples
          </div>
        )}
        {classData.samples.map((sample) => (
          <div key={sample.id} className="relative group flex-shrink-0">
            <img 
              src={sample.src} 
              alt="Sample" 
              className="w-16 h-16 object-cover rounded-md border border-slate-600"
            />
            <button 
              onClick={() => removeSample(sample.id)}
              className="absolute -top-1 -right-1 bg-red-500 text-white rounded-full p-0.5 opacity-0 group-hover:opacity-100 transition-opacity shadow-sm"
            >
              <X size={12} />
            </button>
          </div>
        ))}
        <div className="text-xs text-slate-400 self-end ml-auto whitespace-nowrap">
          {classData.samples.length} samples
        </div>
      </div>
    </div>
  );
};

export default ClassManager;