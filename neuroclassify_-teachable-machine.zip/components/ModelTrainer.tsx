import React from 'react';
import { Play, CheckCircle, Activity, AlertTriangle } from 'lucide-react';
import { ClassData, TrainingState } from '../types';
import { MIN_SAMPLES_PER_CLASS } from '../constants';

interface ModelTrainerProps {
  classes: ClassData[];
  trainingState: TrainingState;
  onTrain: () => void;
}

const ModelTrainer: React.FC<ModelTrainerProps> = ({ classes, trainingState, onTrain }) => {
  
  const canTrain = classes.length >= 2 && classes.every(c => c.samples.length >= MIN_SAMPLES_PER_CLASS);

  const getStatusColor = (model: string) => {
    return trainingState.trainedModels.some(m => m.includes(model)) ? 'text-green-400' : 'text-slate-500';
  };

  return (
    <div className="bg-slate-800 p-6 rounded-xl shadow-lg border border-slate-700">
      <h2 className="text-2xl font-bold mb-4 flex items-center gap-2">
        <Activity className="text-purple-400" />
        Training Center
      </h2>

      <div className="grid grid-cols-3 gap-4 mb-6">
        {/* Model 1: CNN */}
        <div className="bg-slate-700/50 p-3 rounded-lg border border-slate-600">
          <div className="flex justify-between items-start mb-2">
            <span className="text-sm font-semibold text-slate-200">CNN (MobileNet)</span>
            <CheckCircle size={16} className={trainingState.trainedModels.includes('CNN') ? "text-green-400" : "text-slate-600"} />
          </div>
          <div className="text-xs text-slate-400">Deep Learning / Transfer</div>
        </div>

        {/* Model 2: Simple/Logistic */}
        <div className="bg-slate-700/50 p-3 rounded-lg border border-slate-600">
          <div className="flex justify-between items-start mb-2">
            <span className="text-sm font-semibold text-slate-200">Simple (Heuristic)</span>
            <CheckCircle size={16} className={trainingState.trainedModels.includes('SIMPLE') ? "text-green-400" : "text-slate-600"} />
          </div>
          <div className="text-xs text-slate-400">Baseline / Color Hist</div>
        </div>

        {/* Model 3: Gemini */}
        <div className="bg-slate-700/50 p-3 rounded-lg border border-slate-600">
          <div className="flex justify-between items-start mb-2">
            <span className="text-sm font-semibold text-slate-200">Gemini 2.5</span>
            <CheckCircle size={16} className={trainingState.trainedModels.includes('GEMINI') ? "text-green-400" : "text-slate-600"} />
          </div>
          <div className="text-xs text-slate-400">Zero-Shot Reasoning</div>
        </div>
      </div>

      {trainingState.isTraining ? (
        <div className="space-y-2">
          <div className="flex justify-between text-sm text-slate-300">
            <span>Training models...</span>
            <span>{trainingState.progress}%</span>
          </div>
          <div className="w-full bg-slate-700 rounded-full h-2.5">
            <div 
              className="bg-purple-500 h-2.5 rounded-full transition-all duration-300" 
              style={{ width: `${trainingState.progress}%` }}
            ></div>
          </div>
        </div>
      ) : (
        <button
          onClick={onTrain}
          disabled={!canTrain}
          className={`w-full py-3 rounded-lg font-bold flex items-center justify-center gap-2 transition-all ${
            canTrain 
              ? 'bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-500 hover:to-blue-500 shadow-lg hover:shadow-purple-500/25' 
              : 'bg-slate-700 text-slate-500 cursor-not-allowed'
          }`}
        >
          <Play size={20} fill={canTrain ? "currentColor" : "none"} />
          {canTrain ? "Train Model Suite" : "Add Samples to Train"}
        </button>
      )}

      {!canTrain && (
        <div className="mt-3 flex items-start gap-2 text-yellow-500 text-xs bg-yellow-500/10 p-2 rounded border border-yellow-500/20">
          <AlertTriangle size={14} className="mt-0.5 shrink-0"/>
          <p>Requires at least 2 classes with {MIN_SAMPLES_PER_CLASS} samples each.</p>
        </div>
      )}
      
      {trainingState.accuracy !== null && (
        <div className="mt-4 pt-4 border-t border-slate-700 flex justify-around text-center">
           <div>
             <div className="text-xs text-slate-400 uppercase tracking-wider">Accuracy</div>
             <div className="text-xl font-bold text-green-400">{(trainingState.accuracy * 100).toFixed(1)}%</div>
           </div>
           <div>
             <div className="text-xs text-slate-400 uppercase tracking-wider">Epochs</div>
             <div className="text-xl font-bold text-blue-400">50</div>
           </div>
           <div>
             <div className="text-xs text-slate-400 uppercase tracking-wider">Status</div>
             <div className="text-xl font-bold text-white">Ready</div>
           </div>
        </div>
      )}
    </div>
  );
};

export default ModelTrainer;